import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  { path: 'books', loadChildren: () => import('./library-features/library-features.module').then(m => m.LibraryFeaturesModule)},
  { path: 'search', loadChildren: () => import('./custom-search/custom-search.module').then(m => m.CustomSearchModule)},
  { path: '', redirectTo: '/books', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
