import { CustomModule } from './../custom/custom.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LibraryFeaturesRoutingModule } from './library-features-routing.module';
import { BookAddComponent } from './books/book-add/book-add.component';
import { BookListComponent } from './books/book-list/book-list.component';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [BookAddComponent, BookListComponent],
  imports: [
    CommonModule,
    LibraryFeaturesRoutingModule,
    ReactiveFormsModule,
    CustomModule
  ]
})
export class LibraryFeaturesModule { }
