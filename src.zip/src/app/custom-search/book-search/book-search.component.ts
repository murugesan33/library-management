import { BookApiService } from "./../../library-features/books/services/book-api.service";
import { IBooks } from "./../../models/model";
import { ApplicationConstants } from "./../../constants/applicationConstants";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-book-search",
  templateUrl: "./book-search.component.html",
  styleUrls: ["./book-search.component.css"]
})
export class BookSearchComponent implements OnInit {
  public categoryList: string[];
  /* a boolean variable to show error in the validation */
  public showFilterError: boolean = false;
  public showTable: boolean = false;
  public bookList: IBooks[];
  public filteredData: IBooks[];

  constructor(private bookApi: BookApiService) {}

  ngOnInit() {
    /* to get the list of categories to display in filter*/
    this.categoryList = ApplicationConstants.bookCategories;
    /* to read the list of boooks from api */
    this.getListOfBooks();
  }
  /* method to filter category based on selection 
seleected category will be passed to this method to filter the data
*/
  public filterByCategory(category: string) {
    if (category) {
      this.filteredData = this.bookList.filter(
        data => data.bookCategory === category
      );
      if (this.filteredData.length > 0) {
        this.showTable = true;
      } else {
        this.showTable = false;
      }

      this.showFilterError = false;
    } else {
      this.showFilterError = true;
    }
  }
/* method to get all the book details*/
  public getListOfBooks() {
    this.bookApi.getBooks().subscribe(data => {
      this.bookList = data;
    });
  }
}
